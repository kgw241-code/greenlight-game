import fs from 'node:fs';
const files={};
for(const name of ['index.html','styles.css','driver.css','app.js','dashboard.js'])files['/'+name]=fs.readFileSync('dist/'+name,'utf8');
const api=fs.readFileSync('worker/api.mjs','utf8').replace('export async function api','async function api');
fs.mkdirSync('dist/server',{recursive:true});fs.mkdirSync('dist/.openai',{recursive:true});
fs.writeFileSync('dist/server/index.js',api+'\nconst assets='+JSON.stringify(files)+';\nexport default {async fetch(request,env){const p=new URL(request.url).pathname;if(p.startsWith("/api/"))return api(request,env);if(request.method!=="GET"&&request.method!=="HEAD")return new Response("Method not allowed",{status:405});const key=p==="/"?"/index.html":p;if(!(key in assets))return new Response("Not found",{status:404});return new Response(request.method==="HEAD"?null:assets[key],{headers:{"Content-Type":key.endsWith(".css")?"text/css; charset=utf-8":key.endsWith(".js")?"application/javascript; charset=utf-8":"text/html; charset=utf-8","Cache-Control":"no-cache"}})}};');
fs.copyFileSync('.openai/hosting.json','dist/.openai/hosting.json');
