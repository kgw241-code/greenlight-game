CREATE TABLE participants (id TEXT PRIMARY KEY NOT NULL, best_ms REAL NOT NULL, latest_ms REAL NOT NULL);
--> statement-breakpoint
CREATE TABLE results (participant_id TEXT NOT NULL, game_id TEXT NOT NULL, average_ms REAL NOT NULL, rounds_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (participant_id,game_id));
--> statement-breakpoint
CREATE INDEX participants_best_idx ON participants(best_ms);
