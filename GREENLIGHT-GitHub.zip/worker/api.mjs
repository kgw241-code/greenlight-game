const json = (body, status=200, cookie) => new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...(cookie?{'Set-Cookie':cookie}:{})}});
export async function api(request,env){
  if(!env.DB) return json({error:'기록 저장소를 준비 중입니다.'},503);
  const url=new URL(request.url);
  const match=(request.headers.get('Cookie')||'').match(/(?:^|;\s*)greenlight_id=([a-f0-9]{32})(?:;|$)/);
  const id=match?.[1]||crypto.randomUUID().replaceAll('-','');
  const cookie=`greenlight_id=${id}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=31536000`;
  try{
    if(url.pathname==='/api/results'&&request.method==='POST'){
      if(request.headers.get('Origin')!==url.origin) return json({error:'허용되지 않은 요청입니다.'},403);
      if(Number(request.headers.get('Content-Length'))>4096) return json({error:'요청이 너무 큽니다.'},413);
      const raw=await request.text();if(raw.length>4096)return json({error:'요청이 너무 큽니다.'},413);
      let body;try{body=JSON.parse(raw);}catch{return json({error:'기록 형식이 올바르지 않습니다.'},400);}
      if(!/^[a-f0-9-]{36}$/.test(body.gameId||'')||!Array.isArray(body.rounds)||body.rounds.length!==5||body.rounds.some(n=>!Number.isSafeInteger(n)||n<0||n>3600000))return json({error:'유효한 5회 측정 기록이 필요합니다.'},400);
      const avg=Math.round(body.rounds.reduce((a,b)=>a+b,0)/5*10)/10;
      await env.DB.batch([
        env.DB.prepare('INSERT OR IGNORE INTO results (participant_id, game_id, average_ms, rounds_json) VALUES (?, ?, ?, ?)').bind(id,body.gameId,avg,JSON.stringify(body.rounds)),
        env.DB.prepare('INSERT INTO participants (id, best_ms, latest_ms) VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET best_ms=MIN(participants.best_ms,excluded.best_ms), latest_ms=excluded.latest_ms').bind(id,avg,avg)
      ]);
    }else if(url.pathname!=='/api/standings'||request.method!=='GET')return json({error:'찾을 수 없습니다.'},404);
    const mine=await env.DB.prepare('SELECT best_ms,latest_ms FROM participants WHERE id=?').bind(id).first();
    const group=await env.DB.prepare('SELECT COUNT(*) AS total, AVG(best_ms) AS average FROM participants').first();
    const top=await env.DB.prepare('SELECT best_ms FROM participants ORDER BY best_ms ASC,id ASC LIMIT 10').all();
    let rank=null,slower=null,peers=Math.max(0,group.total-(mine?1:0));
    if(mine){const counts=await env.DB.prepare('SELECT SUM(CASE WHEN best_ms < ? THEN 1 ELSE 0 END) AS faster, SUM(CASE WHEN best_ms > ? THEN 1 ELSE 0 END) AS slower FROM participants WHERE id<>?').bind(mine.best_ms,mine.best_ms,id).first();rank=Number(counts.faster||0)+1;slower=peers?Number(counts.slower||0)/peers*100:null;}
    return json({mine,total:group.total,groupAverage:group.average,rank,topPercent:mine?rank/group.total*100:null,slowerPercent:slower,peers,top:top.results.map((row,i,arr)=>({rank:arr.findIndex(r=>r.best_ms===row.best_ms)+1,ms:row.best_ms}))},200,cookie);
  }catch{return json({error:'서버에 연결하지 못했습니다. 잠시 후 다시 시도하세요.'},503,cookie);}
}
